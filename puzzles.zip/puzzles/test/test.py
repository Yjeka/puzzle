#!/usr/bin/python3
import sys
from pathlib import Path

def check_order(result_base: list[str], connection_size: int) -> bool:
    """Each next puzzle must be connected to previous in right order. Checks this here."""
    assert isinstance(result_base, list)
    assert isinstance(connection_size, int)

    for i in range(len(result_base)-1):
        current_puzzle_right_part = result_base[i][-connection_size:]
        next_puzzle_left_part = result_base[i+1][:connection_size]

        if current_puzzle_right_part != next_puzzle_left_part:
            return False
    return True

def create_result_base(result: str, connection_size: int, middle_size: int) -> list[str]:
    """As result create and return a list of puzzles."""
    assert isinstance(result, str)
    assert isinstance(connection_size, int)
    assert isinstance(middle_size, int)

    result_base = []
    puzzle_size_without_right_part = connection_size + middle_size
    puzzle_size = puzzle_size_without_right_part + connection_size

    for i in range(0, len(result) - connection_size, puzzle_size_without_right_part):
        puzzle = result[i: i+puzzle_size]
        result_base.append(puzzle)
    return result_base

def get_file_path() -> Path:
    """Use default file or file that was specified like parameter when program was start."""
    try:
        file_path = Path(sys.argv[2])
        print(f"Use {file_path=}.")
    except IndexError:
        file_path = Path("../database/puzzles.txt")
        print(f"Use default {file_path=}.")
    return file_path

def is_valid_puzzles(result_base: list[str], puzzles_base: set[str]) -> bool:
    """Check if 'puzzles_base' contains all puzzles from result_base"""
    assert isinstance(result_base, list)
    assert isinstance(puzzles_base, set)

    for puzzle in result_base:
        if puzzle not in puzzles_base:
            return False
    return True

def load_puzzles_base(file_path: Path) -> set[str]:
    """As result create and return a set of puzzles."""
    assert isinstance(file_path, Path)

    puzzles_base = set()
    try:
        with open(file_path, "r") as file:
            for puzzle in file:
                puzzles_base.add(puzzle.rstrip())
    except IOError:
        print("Specified file not exists.", file=sys.stderr)
        exit(1)
    return puzzles_base
    

if __name__ == "__main__":
    try:
        result = sys.argv[1]
    except:
        print("What to test? Specify result row. Information in readme.txt file.")
        exit(1)
    file_path = get_file_path()
    try:
        connection_size = int(sys.argv[3])
        print(f"Use {connection_size=}.")
    except ValueError:
        print("Only digits.")
        exit(1)
    except:
        connection_size = 2
        print(f"Use default {connection_size=}.")
    try:
        middle_size = int(sys.argv[4])
        print(f"Use {middle_size=}.")
    except ValueError:
        print("Only digits.")
        exit(1)
    except:
        middle_size = 2
        print(f"Use default {middle_size=}.")

    puzzles_base = load_puzzles_base(file_path)

    try:
        result_base = create_result_base(result, connection_size, middle_size)
    except:
        print("Failed to retrieve puzzles from result row, sequence length is wrong.",
              "\n(Information in readme.txt file)")
        exit(1)
    try:
        int(result)
        test = True
    except:
        test = False

    print(len(result_base), "- puzzles in the row.")
    print(test, "- All digits.")

    test = is_valid_puzzles(result_base, puzzles_base)
    print(test, "- All valid puzzles.")

    test = len(set(result_base)) == len(result_base)
    print(test, "- All unique puzzles.")

    test = check_order(result_base, connection_size)
    print(test, "- All puzzles in right order.")
