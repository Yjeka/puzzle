This is sequense of tests to check result of program.
You can run test like: ./test.py str_with_result_of_main.py.
 If you use another file with puzzles, specify path to it: ./test.py str_with_result_of_main.py path_to_file.
 If you use not default connection_size specify it: ./test.py str_with_result_of_main.py path_to_file connection_size.
 If you use not default middle_size specify it: ./test.py str_with_result_of_main.py path_to_file connection_size middle_size.
