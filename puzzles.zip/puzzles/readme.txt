This program write on Python3 language. You need install interpreter to run it(https://www.python.org/downloads/).

 Starting point is main.py file. That to run need write in command line from program directory(python3 main.py). You can make file executable and run it from command line like(./main.py).

 Program can take optional argument(main.py path_to_file), if not specified will be used default file (puzzles.txt). Optional argument is text file that contains some sequence of digits in each row that represent a puzzles. The ammount of digits must be more than 4 in each row and each row must be unique. Wrong rows will be skipped by program.

 As result you get longest row of connected puzzles. Seems like this task is NP-full, that need some time to finish(~6 minutes for default file).
