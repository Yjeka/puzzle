class Puzzle:
    def __init__(self, puzzle: str, connection_size: int=2):
        """Constructor that creates new Puzzle object. Saves necessary information about puzzle.
           Parameter 'puzzle' must contain only digits and must have valid length (len(puzzle) > 
           connection_size * 2).
        """ 
        assert isinstance(puzzle, str)
        assert isinstance(connection_size, int)
        assert len(puzzle) > connection_size * 2

        self.__connection_size = connection_size
        self.__hash_value = hash(int(puzzle))
        self.__left, self.__middle, self.__right = self.__split_on_parts(puzzle)

    def __convert_to_str(self, connection_part: int) -> str:
        """Converted to 'str' type and add zeros to the left side of 'connection_part' if needed."""
        assert isinstance(connection_part, int)

        connection_part = str(connection_part)
        diff_size = self.__connection_size - len(connection_part)

        if diff_size:
            connection_part = "0" * diff_size + connection_part
        return connection_part

    def __split_on_parts(self, puzzle: str) -> tuple[int]:
        """Cuts puzzle on three parts and converted each part to 'int' type.
           'left' and 'right' parts need for connection puzzle with other puzzles
           (example: if 'right' part of one puzzle the same like 'left' part of other puzzle
           then they can be connected).
        """
        assert isinstance(puzzle, str)

        cut_index = self.__connection_size
        left = int(puzzle[:cut_index])
        middle = int(puzzle[cut_index:-cut_index])
        right = int(puzzle[-cut_index:])

        return (left, middle, right)

    def __eq__(self, value):
        return self.left == value.left and self.middle == value.middle and self.right == value.right

    def __hash__(self):
        return self.__hash_value

    def __ne__(self, value):
        return not self.__eq__(value)

    @property
    def left(self) -> int:
        return self.__left

    @property
    def middle(self) -> int:
        return self.__middle

    @property
    def right(self) -> int:
        return self.__right

    def get_left_and_middle_part(self) -> str:
        """Returns puzzle without right part converted to 'str' type."""
        return self.__convert_to_str(self.left) + self.__convert_to_str(self.middle)

    def get_right_part(self) -> str:
        """Returns right part of the puzzle converted to 'str' type."""
        return self.__convert_to_str(self.right)
