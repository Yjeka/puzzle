#!/usr/bin/python3
from pathlib import Path
import sys

import lib.puzzle as p

def add_to(puzzles_base: dict, puzzle: p.Puzzle) -> bool:
    """Add to database only unique puzzle."""
    assert isinstance(puzzles_base, dict)
    assert isinstance(puzzle, p.Puzzle)

    left_connection = puzzle.left

    if left_connection in puzzles_base:
        if puzzle in puzzles_base[left_connection]:
            return False
        puzzles_base[left_connection].add(puzzle)
    else:
        puzzles_base[left_connection] = {puzzle}
    return True

def find_longest_sequence(puzzles_base: dict, amount_of_puzzles: int) -> list[p.Puzzle]:
    """In result must get the longest row of puzzles that will be choosen from other sequences.
       For this, recursive addition of puzzles to each separate subsequence is implemented.
    """
    assert isinstance(puzzles_base, dict)
    assert isinstance(amount_of_puzzles, int)

    print(f"{amount_of_puzzles} dots is expected.",
          "You can go to make some tea:)", file=sys.stderr)
    longest_sequence = []

    for values_set in puzzles_base.values():
        for puzzle in values_set:
            result = recursive_expand(list(), set(), puzzle, puzzles_base, amount_of_puzzles)
            print(".", end="", flush=True, file=sys.stderr)

            if len(result) == amount_of_puzzles:
                print(file=sys.stderr)
                return result
            elif len(result) > len(longest_sequence):
                longest_sequence = result
    print(file=sys.stderr)
    return longest_sequence

def get_file_path() -> Path:
    """Use default file or file that was specified like parameter when program was start."""
    try:
        file_path = Path(sys.argv[1])
    except IndexError:
        file_path = Path("./database/puzzles.txt")
    return file_path

def load_puzzles_base(file_path: Path) -> tuple[dict, int]:
    """As result create and return a dictionary where:
         key - left connection part of puzzle;
         value - set of unique puzzles that have the same left connection part.
       Also returns amount of added puzzles to dictionary.
       *This dictionary will be used for reading purpose only.
    """
    assert isinstance(file_path, Path)

    puzzles_base = dict()
    count = 0
    amount_of_add_puzzles = 0

    try:
        with open(file_path, "r") as file:
            for puzzle in file:
                puzzle = puzzle.rstrip()
                count += 1

                try:
                    next_puzzle = p.Puzzle(puzzle)
                except:
                    print(f"{count} row in file: {puzzle}.", "Puzzle - is incorrect, skip it.",
                          file=sys.stderr)
                    continue

                if add_to(puzzles_base, next_puzzle):
                    amount_of_add_puzzles += 1
                else:
                    print(f"{count} row in file: {puzzle}.", "Puzzle - is not unique, skip it.",
                          file=sys.stderr)
    except IOError:
        print("Specified file not exists.", file=sys.stderr)
        exit(1)
    return (puzzles_base, amount_of_add_puzzles)

def recursive_expand(sequence: list[p.Puzzle], used_puzzles: set[p.Puzzle], puzzle: p.Puzzle,
                                    puzzles_base: dict, amount_of_puzzles: int) -> list[p.Puzzle]:
    """DFS algorithm for graphs."""
    assert isinstance(sequence, list)
    assert isinstance(used_puzzles, set)
    assert isinstance(puzzle, p.Puzzle)
    assert isinstance(puzzles_base, dict)
    assert isinstance(amount_of_puzzles, int)

    longest_sequence = sequence

    if puzzle in used_puzzles:
        return longest_sequence

    sequence.append(puzzle)
    used_puzzles.add(puzzle)
    right_connection = puzzle.right

    try:
        values_set = puzzles_base[right_connection]
    except:
        return longest_sequence

    for puzzle in values_set:
        result = recursive_expand(sequence[:], used_puzzles.copy(), puzzle, puzzles_base,
                                                                        amount_of_puzzles)
        if len(result) == amount_of_puzzles:
            return result
        elif len(result) > len(longest_sequence):
            longest_sequence = result
    return longest_sequence

def show_result(longest_sequence: list[p.Puzzle]) -> None:
    """Prints longest row of puzzles in specified format."""
    assert isinstance(longest_sequence, list)

    for puzzle in longest_sequence:
        print(puzzle.get_left_and_middle_part(), end="")
    print(puzzle.get_right_part())


if __name__ == "__main__":
    file_path = get_file_path()
    puzzles_base, amount_of_puzzles = load_puzzles_base(file_path)

    if not amount_of_puzzles:
        print("Seems the file is empty or no find valid puzzles in the file.", file=sys.stderr)
        exit(1)

    longest_sequence = find_longest_sequence(puzzles_base, amount_of_puzzles)
    show_result(longest_sequence)
